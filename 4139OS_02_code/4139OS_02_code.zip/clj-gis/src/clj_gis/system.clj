
(ns clj-gis.system)

(defn system []
  {})

(defn start
  [system]
  system)

(defn stop
  [system]
  system)

