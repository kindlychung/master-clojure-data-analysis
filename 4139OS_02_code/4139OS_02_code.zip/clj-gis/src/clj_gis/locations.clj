
(ns clj-gis.locations)

(def ^:dynamic *download-dir* "./tars/")
(def ^:dynamic *data-dir* "./data/")
(def ^:dynamic *ish-history-file* "./ish-history.csv")

