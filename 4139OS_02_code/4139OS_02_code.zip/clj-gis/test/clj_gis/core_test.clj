(ns clj-gis.core-test
  (:use clojure.test
        clj-gis.core))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
