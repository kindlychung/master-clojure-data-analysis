(ns ufo-data.core-test
  (:use clojure.test
        ufo-data.core))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
